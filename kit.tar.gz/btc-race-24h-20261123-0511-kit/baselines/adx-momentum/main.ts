// Baseline: ADX trend momentum, long only. The rules are those freqtrade-strategies publishes as
// ADXMomentum (user_data/strategies/berlinguyinca/ADXMomentum.py at
// f3340ce11f5bdf62f598522e64d1f5638eaa13f5, https://github.com/freqtrade/freqtrade-strategies),
// written here clean-room from those rules alone: no line of that GPL-3.0 code is copied. ADXMomentum
// trades 1h candles, as solana-bars-1h-01 does.
//
//   - Indicators, per symbol over its own bars (a gap adds nothing: the bars either side of it are
//     neighbours), as TA-Lib computes the ADX, PLUS_DI, MINUS_DI and MOM ADXMomentum reads (the SAR it
//     also computes is never read, and is left out):
//       one bar's moves, from the symbol's bar before: up = h - h before, down = l before - l;
//       +DM = up when up > 0 and up > down, else 0; -DM = down when down > 0 and down > up, else 0;
//       the true range TR = the largest of h - l, |h - c before| and |l - c before|.
//       Wilder's smoothing over n bars (TA-Lib's seeding): the first n - 1 one-bar values summed (the
//       symbol's first bar has none), then each next sum is the last, less 1/n of itself, plus the
//       newest value. +DI(n) = 100 x (+DM sum / TR sum) and -DI(n) likewise, from the symbol's bar
//       n + 1 on; both 0 while the TR sum is 0.
//       ADX(14): DX = 100 x |+DI(14) - -DI(14)| / (+DI(14) + -DI(14)), none on a bar where that sum
//       is 0; the first ADX is the first 14 DX summed (a bar with none adding nothing) over 14, on
//       the symbol's bar 28; each next one (13 x the last + DX) / 14, unchanged on a bar with no DX.
//       MOM(14) = the close less the symbol's close 14 bars before.
//     tests/unit/baselines.test.ts holds these lookbacks and values to TA-Lib 0.8.3's.
//   - Entry, on a bar's close (filled at the next open): ADX(14) above 25, MOM(14) above 0, +DI(25)
//     above 25 and above -DI(25), on a symbol it does not hold.
//   - Exit, the whole position: ADX(14) above 25, MOM(14) below 0, -DI(25) above 25 and +DI(25) below
//     -DI(25) (its sell signal), or the position worth at least 1% over its cost at the close (its
//     minimal_roi {"0": 0.01}), or at least 25% under it (its stoploss -0.25).
//   - Every rule is read again on each of the symbol's bars, so a sell the market refuses (no bar or a
//     price past the slippage cap at the next open) or the order cap leaves out is sent again on the
//     symbol's next bar while its reason still holds at that close, and an entry the market refuses,
//     or a position just sold, is bought again on the next bar that signals it. A symbol with no bar
//     on a batch is not decided on that batch.
//   - Volume: ADXMomentum reads none, and neither does this (a bar's v, 0 or null, holds nothing back).
//   - Stake (freqtrade's stake_amount "unlimited"): equity over n slots, n = min(the universe,
//     caps.max_open_positions); each buy the smallest of equity / n, caps.max_weight_bps of equity and
//     the cash this reply has not spent yet; below fees.min_notional_quote_units it buys nothing. It
//     never holds more than n, counting the positions this reply sells (their proceeds land at the
//     next open and fund later buys, never this reply's).
//   - A reply carries the sells first, then the buys in universe order, at most
//     caps.max_orders_per_bar in all. Each order caps its slippage at MAX_SLIPPAGE_BPS = 100, 1% past
//     the close it was decided on, so a sell into a liquidity gap is refused (and sent again) rather
//     than filled for almost nothing.
//   - The indicators run in float64 on + - * / alone (an absolute value by comparison and negation,
//     every zero test exact: the prices are raw units of any scale), each correctly rounded (IEEE
//     754), so the same bars give the same orders, run after run.
//
// Laid out like an entrant's repository: the grader runs `node /bot/main.ts` with this directory
// mounted at /bot; vendor/makefun-bars.ts is a byte-identical copy of bars/sdk/makefun-bars.ts
// (tests/unit/baselines.test.ts keeps it so).

import { BPS, runBars, type Bar, type BarsState, type BuyInput, type SellInput } from './vendor/makefun-bars.ts';

const ADX_BARS = 14;
const DI_BARS = 25;
const MOM_BARS = 14;
/** ADX(14), and the leading DI(25), above 25: a strong trend. */
const TREND_ABOVE = 25;
/** minimal_roi {"0": 0.01}: worth 101/100 of its cost. */
const ROI = [101n, 100n] as const;
/** stoploss -0.25: worth 3/4 of its cost. */
const STOP = [3n, 4n] as const;
const MAX_SLIPPAGE_BPS = 100;

/** Wilder's sums of +DM, -DM and TR over `span` bars, and how many one-bar moves went in. */
interface Wilder {
  span: number;
  moves: number;
  plus: number;
  minus: number;
  range: number;
}

interface Series {
  /** The symbol's bar before this one. */
  prev: { h: number; l: number; c: number } | null;
  /** Its last MOM_BARS + 1 closes, oldest first. */
  closes: number[];
  /** The sums the ADX's DIs come from (14 bars), and those of the entry's and exit's DIs (25). */
  short: Wilder;
  long: Wilder;
  /** The first ADX_BARS DX summed, and how many bars went in, until the ADX starts. */
  dxSum: number;
  dxBars: number;
  adx: number | null;
}

type Signal = 'up' | 'down' | null;

const series = new Map<string, Series>();

const wilder = (span: number): Wilder => ({ span, moves: 0, plus: 0, minus: 0, range: 0 });
const abs = (x: number) => (x < 0 ? -x : x);

function smooth(w: Wilder, plus: number, minus: number, range: number): void {
  w.moves++;
  if (w.moves < w.span) {
    w.plus += plus;
    w.minus += minus;
    w.range += range;
    return;
  }
  w.plus = w.plus - w.plus / w.span + plus;
  w.minus = w.minus - w.minus / w.span + minus;
  w.range = w.range - w.range / w.span + range;
}

/** [+DI, -DI] once the sums hold `span` moves, else null. */
function dis(w: Wilder): [number, number] | null {
  if (w.moves < w.span) return null;
  if (w.range === 0) return [0, 0];
  return [100 * (w.plus / w.range), 100 * (w.minus / w.range)];
}

/** Fold a bar into its symbol's indicators; the signal they give on its close. */
function push(bar: Bar): Signal {
  let s = series.get(bar.symbol);
  if (s === undefined) series.set(bar.symbol, (s = { prev: null, closes: [], short: wilder(ADX_BARS), long: wilder(DI_BARS), dxSum: 0, dxBars: 0, adx: null }));
  const h = Number(bar.h);
  const l = Number(bar.l);
  const c = Number(bar.c);
  if (s.prev !== null) {
    const up = h - s.prev.h;
    const down = s.prev.l - l;
    const plus = up > 0 && up > down ? up : 0;
    const minus = down > 0 && down > up ? down : 0;
    let range = h - l;
    if (abs(h - s.prev.c) > range) range = abs(h - s.prev.c);
    if (abs(l - s.prev.c) > range) range = abs(l - s.prev.c);
    smooth(s.short, plus, minus, range);
    smooth(s.long, plus, minus, range);
    const di = dis(s.short);
    if (di !== null) {
      const sum = di[0] + di[1];
      const dx = sum === 0 ? null : 100 * (abs(di[0] - di[1]) / sum);
      if (s.adx === null) {
        if (dx !== null) s.dxSum += dx;
        if (++s.dxBars === ADX_BARS) s.adx = s.dxSum / ADX_BARS;
      } else if (dx !== null) s.adx = (s.adx * (ADX_BARS - 1) + dx) / ADX_BARS;
    }
  }
  s.prev = { h, l, c };
  s.closes.push(c);
  if (s.closes.length > MOM_BARS + 1) s.closes.shift();

  const di = dis(s.long);
  if (s.adx === null || di === null || s.closes.length <= MOM_BARS || !(s.adx > TREND_ABOVE)) return null;
  const mom = c - s.closes[0]!;
  const [plusDi, minusDi] = di;
  if (mom > 0 && plusDi > TREND_ABOVE && plusDi > minusDi) return 'up';
  if (mom < 0 && minusDi > TREND_ABOVE && plusDi < minusDi) return 'down';
  return null;
}

/** Whether a held position exits on this close: the sell signal, or its value at the ROI or the stoploss. */
function exits(state: BarsState, symbol: string, held: { qty: bigint; cost: bigint }, signal: Signal): boolean {
  if (signal === 'down') return true;
  const value = state.value(symbol, held.qty);
  return value * ROI[1] >= held.cost * ROI[0] || value * STOP[1] <= held.cost * STOP[0];
}

await runBars({
  onBatch(state, batch) {
    const signals = new Map<string, Signal>();
    for (const bar of batch.bars) signals.set(bar.symbol, push(bar));
    const { caps, fees } = state.hello;
    const sells: SellInput[] = [];
    const entries: string[] = [];
    for (const { symbol } of state.hello.symbols) {
      if (!signals.has(symbol)) continue;
      const signal = signals.get(symbol)!;
      const held = state.positions.get(symbol);
      if (held !== undefined) {
        if (exits(state, symbol, held, signal)) sells.push({ side: 'sell', symbol, qty: held.qty, max_slippage_bps: MAX_SLIPPAGE_BPS });
      } else if (signal === 'up') entries.push(symbol);
    }

    const orders: (SellInput | BuyInput)[] = sells.slice(0, caps.max_orders_per_bar);
    const slots = Math.min(state.hello.symbols.length, caps.max_open_positions);
    const stake = state.equity / BigInt(slots);
    const byWeight = (BigInt(caps.max_weight_bps) * state.equity) / BPS;
    let room = slots - state.positions.size;
    let cash = state.cash;
    for (const symbol of entries) {
      if (room <= 0 || orders.length >= caps.max_orders_per_bar) break;
      let slice = stake < byWeight ? stake : byWeight;
      if (cash < slice) slice = cash;
      if (slice === 0n || slice < BigInt(fees.min_notional_quote_units)) break;
      orders.push({ side: 'buy', symbol, notional_quote_units: slice, max_slippage_bps: MAX_SLIPPAGE_BPS });
      cash -= slice;
      room--;
    }
    return orders;
  },
});
