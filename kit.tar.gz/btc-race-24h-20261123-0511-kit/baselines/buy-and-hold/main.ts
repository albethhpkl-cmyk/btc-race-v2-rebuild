// Baseline: buy and hold, the bars bundles' published house baseline (prize_requires_beating_baseline:
// an entry is paid only for beating it). On the first batch it can trade on that prices a symbol
// (batch 0 of a window with no leading gap; with a warm-up, hello.warmup_bars, the first batch after
// it, whose orders the replay takes) it buys an equal notional slice of every symbol it can, then
// never trades again; the replay flattens the positions at the end.
//
//   - The symbols: those with a latest close on that batch, in universe (code-unit) order, the first
//     n = min(their count, caps.max_open_positions, caps.max_orders_per_bar) of them.
//   - The slice: min(cash / n, caps.max_weight_bps x equity / 10000), truncated, the same for each, so
//     the buys together never spend more than the cash and none passes the weight cap. Below
//     fees.min_notional_quote_units it buys nothing.
//   - Slippage is left wide open (MAX_SLIPPAGE_BPS = 10_000): the baseline measures holding the
//     universe, whatever the next open does. An order the market still refuses (no bar at the next
//     open) is not retried.
//
// Laid out like an entrant's repository: the grader runs `node /bot/main.ts` with this directory
// mounted at /bot; vendor/makefun-bars.ts is a byte-identical copy of bars/sdk/makefun-bars.ts
// (tests/unit/baselines.test.ts keeps it so).

import { BPS, runBars, type BuyInput } from './vendor/makefun-bars.ts';

const MAX_SLIPPAGE_BPS = 10_000;

let decided = false;

await runBars({
  onBatch(state) {
    // While warming up every order would be rejected (warmup) and never retried: wait for the window.
    if (decided || state.warmingUp) return [];
    const { caps, fees } = state.hello;
    const priced = state.hello.symbols.map((s) => s.symbol).filter((symbol) => state.close(symbol) !== null);
    if (priced.length === 0) return [];
    decided = true;
    const n = Math.min(priced.length, caps.max_open_positions, caps.max_orders_per_bar);
    const even = state.cash / BigInt(n);
    const byWeight = (BigInt(caps.max_weight_bps) * state.equity) / BPS;
    const slice = even < byWeight ? even : byWeight;
    if (slice === 0n || slice < BigInt(fees.min_notional_quote_units)) return [];
    return priced.slice(0, n).map((symbol): BuyInput => ({ side: 'buy', symbol, notional_quote_units: slice, max_slippage_bps: MAX_SLIPPAGE_BPS }));
  },
});
